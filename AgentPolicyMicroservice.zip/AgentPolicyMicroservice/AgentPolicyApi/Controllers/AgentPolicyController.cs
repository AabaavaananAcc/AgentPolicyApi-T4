using Microsoft.AspNetCore.Mvc;
using AgentPolicyApi.Models;

namespace AgentPolicyApi.Controllers;

[ApiController]
[Route("AgentPolicy")]
public class AgentPolicyController : ControllerBase
{
    private readonly ILogger<AgentPolicyController> _logger;

    public AgentPolicyController(ILogger<AgentPolicyController> logger)
    {
        _logger = logger;
    }

    [HttpGet("GetAllAgentPolicies")]
    public IEnumerable<AgentPolicy> GetAllAgentPolicies()
    {
        AgentPolicyViewModel agentPolicyViewModel= new AgentPolicyViewModel();
        return agentPolicyViewModel.GetAllAgentPolicies();
    }

    [HttpGet("GetAgentPolicyByPolicyCode")]
    public IEnumerable<AgentPolicy> GetAgentPolicyByPolicyCode(string agentPolicyCode)
    {
        AgentPolicyViewModel agentPolicyViewModel= new AgentPolicyViewModel();
        return agentPolicyViewModel.GetAllAgentPolicies(agentPolicyCode);
    }

    [HttpPost("SaveAgentPolicy")]
    public bool SaveAgentPolicy([FromBody]AgentPolicy agentPolicy)
    {
        AgentPolicyViewModel agentPolicyViewModel= new AgentPolicyViewModel();
        return agentPolicyViewModel.SaveAgentPolicy(agentPolicy);
    }

    [HttpPost("UpdateAgentPolicy")]
    public bool UpdateAgentPolicy([FromBody]AgentPolicy agentPolicy)
    {
        AgentPolicyViewModel agentPolicyViewModel= new AgentPolicyViewModel();
        return agentPolicyViewModel.UpdateAgentPolicy(agentPolicy);
    }

    [HttpPost("DeleteAgentPolicy")]
    public bool DeleteAgentPolicy(string agentPolicyCode)
    {
        AgentPolicyViewModel agentPolicyViewModel= new AgentPolicyViewModel();
        return agentPolicyViewModel.DeleteAgentPolicy(agentPolicyCode);
    }
}
