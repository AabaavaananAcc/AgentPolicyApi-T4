namespace AgentPolicyApi.Models;

public class AgentPolicy
{
    public int Id { get; set; }
        public string AgentPolicyCode { get; set; }
        public string AgentPolicyDesc { get; set; }
        public int MaxAllowedAdults { get; set; }
        public int MaxAllowedChildren { get; set; }
        public bool IsSeniorCitizensAllowed { get; set; }
        public int PolicyPremiumPerAdult { get; set; }
        public int PolicyPremimumPerChild { get; set; }
        public DateTime AiredDate { get; set; }
        public bool IsActive { get; set; }
}