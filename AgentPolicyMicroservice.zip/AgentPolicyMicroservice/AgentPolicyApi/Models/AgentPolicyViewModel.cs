using AgentPolicyApiDB.Models;

namespace AgentPolicyApi.Models;

public class AgentPolicyViewModel
{
    public AgentPolicyViewModel()
    {

    }

    public List<AgentPolicy> GetAllAgentPolicies(string agentPolicyCode="")
    {
        List<AgentPolicy> agentPolicies=new List<AgentPolicy>();
        using(var agentPolicyContext= new AgentPolicyContext())
        {
            if(!String.IsNullOrWhiteSpace(agentPolicyCode))
            {
                   agentPolicies = agentPolicyContext.MasterDataAgentPolicies.Where(x=>x.AgentPolicyCode==agentPolicyCode).Select(x=> new AgentPolicy(){
                    AgentPolicyCode=x.AgentPolicyCode,
                    AgentPolicyDesc=x.AgentPolicyDesc,
                    AiredDate=x.AiredDate,
                    IsActive=x.IsActive,
                    MaxAllowedAdults=x.MaxAllowedAdults,
                    MaxAllowedChildren=x.MaxAllowedChildren,
                    IsSeniorCitizensAllowed=x.IsSeniorCitizensAllowed
                   }).ToList<AgentPolicy>();
            }
            else
            {
                agentPolicies = agentPolicyContext.MasterDataAgentPolicies.Select(x=> new AgentPolicy(){
                    AgentPolicyCode=x.AgentPolicyCode,
                    AgentPolicyDesc=x.AgentPolicyDesc,
                    AiredDate=x.AiredDate,
                    IsActive=x.IsActive,
                    MaxAllowedAdults=x.MaxAllowedAdults,
                    MaxAllowedChildren=x.MaxAllowedChildren,
                    IsSeniorCitizensAllowed=x.IsSeniorCitizensAllowed
                   }).ToList<AgentPolicy>();
            }   
        }
        return agentPolicies;
    }

    public bool SaveAgentPolicy(AgentPolicy agentPolicy)
    {
        bool isPolicyCreated =  false;
        using(var agentPolicyContext= new AgentPolicyContext())
        {
            if(agentPolicy != null)
            {
                MasterDataAgentPolicy masterDataAgentPolicy = new MasterDataAgentPolicy();
                masterDataAgentPolicy.AgentPolicyCode = agentPolicy.AgentPolicyCode;
                masterDataAgentPolicy.AgentPolicyDesc = agentPolicy.AgentPolicyDesc;
                masterDataAgentPolicy.AiredDate = agentPolicy.AiredDate;
                masterDataAgentPolicy.IsActive = agentPolicy.IsActive;
                masterDataAgentPolicy.MaxAllowedAdults = agentPolicy.MaxAllowedAdults;
                masterDataAgentPolicy.MaxAllowedChildren = agentPolicy.MaxAllowedChildren;
                masterDataAgentPolicy.IsSeniorCitizensAllowed = agentPolicy.IsSeniorCitizensAllowed;
                masterDataAgentPolicy.PolicyPremiumPerAdult = agentPolicy.PolicyPremiumPerAdult;
                masterDataAgentPolicy.PolicyPremimumPerChild = agentPolicy.PolicyPremimumPerChild;
                masterDataAgentPolicy.CreatedBy="admin";
                masterDataAgentPolicy.CreatedDateTime = DateTime.Now;
                masterDataAgentPolicy.LastModifiedBy="admin";
                masterDataAgentPolicy.LastModifiedOn = DateTime.Now;

                agentPolicyContext.MasterDataAgentPolicies.Add(masterDataAgentPolicy);
                isPolicyCreated = agentPolicyContext.SaveChanges() > 0;
                   
            }
        }
        return isPolicyCreated;
    }

    public bool UpdateAgentPolicy(AgentPolicy agentPolicy)
    {
        bool isPolicyUpdated =  false;
        using(var agentPolicyContext= new AgentPolicyContext())
        {
            if(agentPolicy != null)
            {
                MasterDataAgentPolicy existingMasterDataAgentPolicy = agentPolicyContext.MasterDataAgentPolicies.Where(x=>x.AgentPolicyCode== agentPolicy.AgentPolicyCode).Select(x=>x).FirstOrDefault();
                agentPolicyContext.MasterDataAgentPolicies.Remove(existingMasterDataAgentPolicy);

                MasterDataAgentPolicy masterDataAgentPolicy = new MasterDataAgentPolicy();
                masterDataAgentPolicy.AgentPolicyCode = agentPolicy.AgentPolicyCode;
                masterDataAgentPolicy.AgentPolicyDesc = agentPolicy.AgentPolicyDesc;
                masterDataAgentPolicy.AiredDate = agentPolicy.AiredDate;
                masterDataAgentPolicy.IsActive = agentPolicy.IsActive;
                masterDataAgentPolicy.MaxAllowedAdults = agentPolicy.MaxAllowedAdults;
                masterDataAgentPolicy.MaxAllowedChildren = agentPolicy.MaxAllowedChildren;
                masterDataAgentPolicy.IsSeniorCitizensAllowed = agentPolicy.IsSeniorCitizensAllowed;
                masterDataAgentPolicy.CreatedDateTime = DateTime.Now;
                masterDataAgentPolicy.LastModifiedOn = DateTime.Now;

                agentPolicyContext.MasterDataAgentPolicies.Add(masterDataAgentPolicy);
                isPolicyUpdated = agentPolicyContext.SaveChanges() > 0;
                   
            }
        }
        return isPolicyUpdated;
    }

    public bool DeleteAgentPolicy(string agentPolicyCode)
    {
        bool isPolicyDeleted =  false;
        using(var agentPolicyContext= new AgentPolicyContext())
        {
            if(!String.IsNullOrWhiteSpace(agentPolicyCode))
            {
                MasterDataAgentPolicy existingMasterDataAgentPolicy = agentPolicyContext.MasterDataAgentPolicies.Where(x=>x.AgentPolicyCode== agentPolicyCode).Select(x=>x).FirstOrDefault();
                agentPolicyContext.MasterDataAgentPolicies.Remove(existingMasterDataAgentPolicy);
                isPolicyDeleted = agentPolicyContext.SaveChanges() > 0;
            }
        }
        return isPolicyDeleted;
    }
}