﻿using System;
using System.Collections.Generic;

namespace AgentPolicyApiDB.Models
{
    public partial class MasterDataAgentPolicy
    {
        public int Id { get; set; }
        public string AgentPolicyCode { get; set; }
        public string AgentPolicyDesc { get; set; }
        public int MaxAllowedAdults { get; set; }
        public int MaxAllowedChildren { get; set; }
        public bool IsSeniorCitizensAllowed { get; set; }
        public int PolicyPremiumPerAdult { get; set; }
        public int PolicyPremimumPerChild { get; set; }
        public DateTime AiredDate { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModifiedOn { get; set; }
        public string LastModifiedBy { get; set; }
    }
}
