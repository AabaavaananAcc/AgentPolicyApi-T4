﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace AgentPolicyApiDB.Models
{
    public partial class AgentPolicyContext : DbContext
    {
        public AgentPolicyContext()
        {
        }

        public AgentPolicyContext(DbContextOptions<AgentPolicyContext> options)
            : base(options)
        {
        }

        public virtual DbSet<MasterDataAgentPolicy> MasterDataAgentPolicies { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=localhost;Database=AgentPolicy;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<MasterDataAgentPolicy>(entity =>
            {
                entity.HasKey(e => e.AgentPolicyCode)
                    .HasName("PK__MasterDa__1B8AF45C24BC3F94");

                entity.ToTable("MasterData_AgentPolicy");

                entity.Property(e => e.AgentPolicyCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AgentPolicyDesc)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.AiredDate).HasColumnType("datetime");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.LastModifiedBy)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastModifiedOn).HasColumnType("datetime");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
