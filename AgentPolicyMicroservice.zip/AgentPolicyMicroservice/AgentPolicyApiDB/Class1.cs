﻿namespace AgentPolicyApiDB;
public class Class1
{

}
